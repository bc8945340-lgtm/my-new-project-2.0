(() => {
  "use strict";

  document.getElementById("year").textContent = new Date().getFullYear();

  /* ---------------- Roast curve (signature hero element) ---------------- */
  // Real-shaped roast profile: Charge -> Drying -> Maillard -> First Crack -> Drop
  const roastPoints = [
    { t: 0,    temp: 20,  label: "Charge",       strong: true  },
    { t: 3.5,  temp: 105, label: "Drying ends"   },
    { t: 7.5,  temp: 160, label: "Maillard"      },
    { t: 9.75, temp: 203, label: "First crack",  strong: true  },
    { t: 11.7, temp: 214, label: "Drop",          strong: true  }
  ];

  function drawRoastCurve() {
    const svg = document.getElementById("roast-svg");
    const path = document.getElementById("roast-curve");
    const fillPath = document.getElementById("roast-curve-fill");
    const markersG = document.getElementById("roast-markers");
    const gridG = svg.querySelector(".grid");
    if (!svg || !path) return;

    const W = 560, H = 340;
    const padL = 12, padR = 12, padT = 26, padB = 34;
    const maxT = roastPoints[roastPoints.length - 1].t;
    const minTemp = 15, maxTemp = 225;

    const x = (t) => padL + (t / maxT) * (W - padL - padR);
    const y = (temp) => H - padB - ((temp - minTemp) / (maxTemp - minTemp)) * (H - padT - padB);

    // gridlines (temperature bands)
    let gridHTML = "";
    [50, 100, 150, 200].forEach((temp) => {
      const gy = y(temp);
      gridHTML += `<line x1="${padL}" y1="${gy}" x2="${W - padR}" y2="${gy}" />`;
    });
    gridG.innerHTML = gridHTML;

    // smooth-ish curve via cubic segments between points
    let d = `M ${x(roastPoints[0].t)} ${y(roastPoints[0].temp)}`;
    for (let i = 1; i < roastPoints.length; i++) {
      const p0 = roastPoints[i - 1], p1 = roastPoints[i];
      const cx1 = x(p0.t) + (x(p1.t) - x(p0.t)) * 0.45;
      const cx2 = x(p0.t) + (x(p1.t) - x(p0.t)) * 0.55;
      d += ` C ${cx1} ${y(p0.temp)}, ${cx2} ${y(p1.temp)}, ${x(p1.t)} ${y(p1.temp)}`;
    }
    path.setAttribute("d", d);

    const fillD = `${d} L ${x(maxT)} ${H - padB} L ${x(0)} ${H - padB} Z`;
    fillPath.setAttribute("d", fillD);

    // animate the stroke drawing in
    const length = path.getTotalLength();
    path.style.strokeDasharray = `${length}`;
    path.style.strokeDashoffset = `${length}`;
    path.getBoundingClientRect(); // force reflow
    path.style.transition = "stroke-dashoffset 1.6s cubic-bezier(0.22, 1, 0.36, 1)";
    requestAnimationFrame(() => { path.style.strokeDashoffset = "0"; });

    // markers + labels
    let markerHTML = "";
    roastPoints.forEach((p, i) => {
      const px = x(p.t), py = y(p.temp);
      const above = py > 70;
      const labelY = above ? py - 14 : py + 20;
      const anchor = i === 0 ? "start" : i === roastPoints.length - 1 ? "end" : "middle";
      markerHTML += `
        <circle class="marker-dot" cx="${px}" cy="${py}" r="4.5" />
        <text class="marker-label${p.strong ? " strong" : ""}" x="${px}" y="${labelY}" text-anchor="${anchor}">${p.label}</text>
      `;
    });
    markersG.innerHTML = markerHTML;
  }

  drawRoastCurve();
  window.addEventListener("resize", () => {
    clearTimeout(window.__roastResizeT);
    window.__roastResizeT = setTimeout(drawRoastCurve, 150);
  });

  /* ---------------- Menu: fetch from backend, render tabs ---------------- */
  const tabsEl = document.getElementById("menu-tabs");
  const panelsEl = document.getElementById("menu-panels");
  const statusEl = document.getElementById("menu-status");

  async function loadMenu() {
    statusEl.textContent = "Loading menu…";
    statusEl.classList.remove("is-error");
    try {
      const res = await fetch("/api/menu");
      if (!res.ok) throw new Error("Request failed");
      const data = await res.json();
      renderMenu(data.categories || []);
      statusEl.textContent = "";
    } catch (err) {
      statusEl.textContent = "Couldn't load the menu right now. Please refresh.";
      statusEl.classList.add("is-error");
    }
  }

  function renderMenu(categories) {
    tabsEl.innerHTML = "";
    panelsEl.innerHTML = "";

    categories.forEach((cat, i) => {
      const tab = document.createElement("button");
      tab.className = "menu-tab";
      tab.type = "button";
      tab.id = `tab-${cat.id}`;
      tab.setAttribute("role", "tab");
      tab.setAttribute("aria-controls", `panel-${cat.id}`);
      tab.setAttribute("aria-selected", i === 0 ? "true" : "false");
      tab.textContent = cat.label;
      tab.addEventListener("click", () => activateTab(cat.id));
      tabsEl.appendChild(tab);

      const panel = document.createElement("div");
      panel.className = "menu-panel" + (i === 0 ? " is-active" : "");
      panel.id = `panel-${cat.id}`;
      panel.setAttribute("role", "tabpanel");
      panel.setAttribute("aria-labelledby", `tab-${cat.id}`);

      const grid = document.createElement("div");
      grid.className = "menu-grid";
      cat.items.forEach((item) => {
        const row = document.createElement("div");
        row.className = "menu-item";
        row.innerHTML = `
          <div>
            <p class="menu-item-name">${escapeHTML(item.name)}</p>
            <p class="menu-item-desc">${escapeHTML(item.desc)}</p>
          </div>
          <span class="menu-item-price">$${Number(item.price).toFixed(2)}</span>
        `;
        grid.appendChild(row);
      });
      panel.appendChild(grid);
      panelsEl.appendChild(panel);
    });
  }

  function activateTab(id) {
    tabsEl.querySelectorAll(".menu-tab").forEach((t) => {
      t.setAttribute("aria-selected", t.id === `tab-${id}` ? "true" : "false");
    });
    panelsEl.querySelectorAll(".menu-panel").forEach((p) => {
      p.classList.toggle("is-active", p.id === `panel-${id}`);
    });
  }

  function escapeHTML(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  loadMenu();

  /* ---------------- Hours: fetch from backend ---------------- */
  async function loadHours() {
    try {
      const res = await fetch("/api/hours");
      if (!res.ok) throw new Error("Request failed");
      const data = await res.json();

      const list = document.getElementById("hours-list");
      list.innerHTML = "";
      (data.hours || []).forEach((h) => {
        const row = document.createElement("div");
        row.className = "hours-row";
        row.innerHTML = `<dt>${escapeHTML(h.day)}</dt><dd>${escapeHTML(h.time)}</dd>`;
        list.appendChild(row);
      });

      const addr = document.getElementById("address-block");
      addr.innerHTML = `<p>${escapeHTML(data.address || "")}</p><p>${escapeHTML(data.phone || "")}</p>`;
    } catch (err) {
      const list = document.getElementById("hours-list");
      list.innerHTML = `<div class="hours-row"><dt>Hours unavailable</dt><dd>—</dd></div>`;
    }
  }
  loadHours();

  /* ---------------- Reservation form ---------------- */
  const reserveForm = document.getElementById("reserve");
  const reserveFeedback = document.getElementById("reserve-feedback");
  const reserveBtn = document.getElementById("reserve-submit");

  // don't allow picking a date before today
  const dateInput = document.getElementById("r-date");
  const todayStr = new Date().toISOString().slice(0, 10);
  dateInput.min = todayStr;

  reserveForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    reserveFeedback.textContent = "";
    reserveFeedback.className = "form-feedback";

    const formData = new FormData(reserveForm);
    const payload = {
      name: formData.get("name"),
      email: formData.get("email"),
      phone: formData.get("phone"),
      date: formData.get("date"),
      time: formData.get("time"),
      guests: formData.get("guests"),
      notes: formData.get("notes")
    };

    reserveBtn.disabled = true;
    reserveBtn.textContent = "Sending…";

    try {
      const res = await fetch("/api/reservations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await res.json();

      if (!res.ok || !data.ok) {
        const errors = data.errors || ["Something went wrong. Please try again."];
        reserveFeedback.innerHTML = `<ul>${errors.map((e) => `<li>${escapeHTML(e)}</li>`).join("")}</ul>`;
        reserveFeedback.classList.add("is-error");
        return;
      }

      reserveFeedback.textContent = `Reservation requested — confirmation ${data.reservation.id}. We'll email you shortly.`;
      reserveFeedback.classList.add("is-success");
      reserveForm.reset();
      dateInput.min = todayStr;
    } catch (err) {
      reserveFeedback.textContent = "Couldn't reach the server. Please try again.";
      reserveFeedback.classList.add("is-error");
    } finally {
      reserveBtn.disabled = false;
      reserveBtn.textContent = "Request reservation";
    }
  });

  /* ---------------- Newsletter form ---------------- */
  const nlForm = document.getElementById("newsletter-form");
  const nlFeedback = document.getElementById("newsletter-feedback");

  nlForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    nlFeedback.textContent = "";
    nlFeedback.className = "form-feedback";

    const email = new FormData(nlForm).get("email");
    const submitBtn = nlForm.querySelector("button");
    submitBtn.disabled = true;

    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email })
      });
      const data = await res.json();

      if (!res.ok || !data.ok) {
        nlFeedback.textContent = (data.errors && data.errors[0]) || "Something went wrong.";
        nlFeedback.classList.add("is-error");
        return;
      }

      nlFeedback.textContent = data.alreadySubscribed
        ? "You're already on the list."
        : "Subscribed — welcome aboard.";
      nlFeedback.classList.add("is-success");
      nlForm.reset();
    } catch (err) {
      nlFeedback.textContent = "Couldn't reach the server. Please try again.";
      nlFeedback.classList.add("is-error");
    } finally {
      submitBtn.disabled = false;
    }
  });

  /* ---------------- Mobile nav toggle ---------------- */
  const navToggle = document.querySelector(".nav-toggle");
  const mainNav = document.querySelector(".main-nav");
  if (navToggle) {
    navToggle.addEventListener("click", () => {
      const isOpen = mainNav.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });
  }
})();
