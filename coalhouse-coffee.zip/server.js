const express = require("express");
const fs = require("fs/promises");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

const DATA_DIR = path.join(__dirname, "data");
const MENU_FILE = path.join(DATA_DIR, "menu.json");
const RESERVATIONS_FILE = path.join(DATA_DIR, "reservations.json");
const SUBSCRIBERS_FILE = path.join(DATA_DIR, "subscribers.json");

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// ---------- helpers ----------

async function readJSON(file, fallback) {
  try {
    const raw = await fs.readFile(file, "utf-8");
    return JSON.parse(raw);
  } catch (err) {
    if (err.code === "ENOENT") return fallback;
    throw err;
  }
}

async function writeJSON(file, data) {
  await fs.writeFile(file, JSON.stringify(data, null, 2), "utf-8");
}

// very small write queue so concurrent submissions don't clobber the file
let writeChain = Promise.resolve();
function queueWrite(file, mutateFn) {
  writeChain = writeChain.then(async () => {
    const current = await readJSON(file, []);
    const updated = mutateFn(current);
    await writeJSON(file, current);
    return updated;
  });
  return writeChain;
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const TIME_RE = /^([01]\d|2[0-3]):([0-5]\d)$/;

function isValidDateString(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const d = new Date(value + "T00:00:00");
  return !Number.isNaN(d.getTime());
}

// ---------- API routes ----------

app.get("/api/menu", async (req, res) => {
  const menu = await readJSON(MENU_FILE, { categories: [] });
  res.json(menu);
});

app.get("/api/hours", (req, res) => {
  res.json({
    hours: [
      { day: "Monday – Friday", time: "7:00 AM – 6:00 PM" },
      { day: "Saturday", time: "8:00 AM – 6:00 PM" },
      { day: "Sunday", time: "8:00 AM – 4:00 PM" }
    ],
    address: "214 Furnace Street, Nashik, Maharashtra",
    phone: "+91 98765 43210"
  });
});

app.post("/api/reservations", async (req, res) => {
  const { name, email, phone, date, time, guests, notes } = req.body || {};

  const errors = [];
  if (!name || typeof name !== "string" || name.trim().length < 2) {
    errors.push("Enter a name with at least 2 characters.");
  }
  if (!email || !EMAIL_RE.test(email)) {
    errors.push("Enter a valid email address.");
  }
  if (!date || !isValidDateString(date)) {
    errors.push("Choose a valid date (YYYY-MM-DD).");
  } else {
    const chosen = new Date(date + "T00:00:00");
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (chosen < today) errors.push("Choose a date that hasn't passed yet.");
  }
  if (!time || !TIME_RE.test(time)) {
    errors.push("Choose a valid time.");
  }
  const guestCount = Number(guests);
  if (!Number.isInteger(guestCount) || guestCount < 1 || guestCount > 12) {
    errors.push("Guests must be a number between 1 and 12.");
  }

  if (errors.length) {
    return res.status(400).json({ ok: false, errors });
  }

  const reservation = {
    id: `RES-${Date.now().toString(36).toUpperCase()}`,
    name: name.trim(),
    email: email.trim(),
    phone: phone ? String(phone).trim() : null,
    date,
    time,
    guests: guestCount,
    notes: notes ? String(notes).trim().slice(0, 500) : "",
    createdAt: new Date().toISOString()
  };

  await queueWrite(RESERVATIONS_FILE, (list) => {
    list.push(reservation);
    return reservation;
  });

  res.status(201).json({ ok: true, reservation });
});

app.post("/api/newsletter", async (req, res) => {
  const { email } = req.body || {};
  if (!email || !EMAIL_RE.test(email)) {
    return res.status(400).json({ ok: false, errors: ["Enter a valid email address."] });
  }

  const normalized = email.trim().toLowerCase();
  let alreadySubscribed = false;

  await queueWrite(SUBSCRIBERS_FILE, (list) => {
    if (list.includes(normalized)) {
      alreadySubscribed = true;
    } else {
      list.push(normalized);
    }
    return list;
  });

  res.status(alreadySubscribed ? 200 : 201).json({
    ok: true,
    alreadySubscribed
  });
});

// simple admin view of reservations (no auth — demo only)
app.get("/api/reservations", async (req, res) => {
  const list = await readJSON(RESERVATIONS_FILE, []);
  res.json({ count: list.length, reservations: list });
});

app.get("/api/health", (req, res) => {
  res.json({ ok: true, uptime: process.uptime() });
});

// fallback to index.html for any non-API route
app.get(/^(?!\/api).*/, (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Coalhouse Coffee server running at http://localhost:${PORT}`);
});
