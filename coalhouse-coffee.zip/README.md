# Coalhouse Coffee

A full-stack coffee shop website: an Express backend serving a JSON API, and a
static frontend (vanilla HTML/CSS/JS, no build step) that consumes it.

## Run it

```bash
npm install
npm start
```

Then open **http://localhost:3000**.

The server serves the frontend from `/public` and the API from `/api/*` on
the same port, so there's nothing else to configure.

## Project structure

```
server.js              Express app + API routes
data/menu.json          Menu content (edit this to change what's on the site)
data/reservations.json  Reservation submissions get appended here
data/subscribers.json   Newsletter emails get appended here
public/index.html       Page markup
public/css/style.css    Design system + layout
public/js/main.js       Fetches the API, draws the roast-curve chart, handles forms
```

## API

| Method | Route               | Description                                    |
|--------|---------------------|-------------------------------------------------|
| GET    | `/api/menu`         | Menu categories and items                       |
| GET    | `/api/hours`        | Opening hours and address                        |
| POST   | `/api/reservations` | Create a reservation (validates and stores it)   |
| GET    | `/api/reservations` | List stored reservations (demo — no auth)        |
| POST   | `/api/newsletter`   | Subscribe an email                               |
| GET    | `/api/health`       | Health check                                     |

Reservations and subscribers are stored as JSON files under `data/` — good
enough for a demo or a low-traffic site. For production, swap the
`readJSON`/`writeJSON`/`queueWrite` helpers in `server.js` for a real
database (Postgres, SQLite, etc.) without touching the frontend.

## Customizing

- **Menu / prices**: edit `data/menu.json` — the frontend renders whatever
  categories and items are in there.
- **Hours / address**: edit the object returned by `GET /api/hours` in
  `server.js`.
- **Colors / type**: CSS custom properties at the top of `public/css/style.css`.
- **Reservations notification**: `POST /api/reservations` currently just
  saves to disk. Wire in an email service (e.g. Nodemailer, Resend, Postmark)
  where it says `await queueWrite(RESERVATIONS_FILE, ...)` if you want an
  email sent on each booking.

## Notes

- No authentication is implemented on `GET /api/reservations` — treat it as
  a demo/admin endpoint and add auth before deploying publicly.
- Forms validate both client-side (for instant feedback) and server-side
  (source of truth) — never trust the client alone.
